package sudokuPackage;

import org.testng.annotations.Test;
import sudokuPackage.exception.DaoException;
import sudokuPackage.exception.DatebaseException;

import static org.junit.Assert.*;

public class FileSudokuBoardDaoTest {
    private SudokuBoardDaoFactory factory = new SudokuBoardDaoFactory();
    SudokuSolver backtrackingSolver = new BacktrackingSudokuSolver();
    private SudokuBoard sudokuBoard = new SudokuBoard(backtrackingSolver);
    private Dao<SudokuBoard> file;
    private SudokuBoard sudokuBoard2;

    @Test
    public void writeReadTest() throws DaoException, DatebaseException {
        file = factory.getFileDao("file1");
        file.write(sudokuBoard);
        sudokuBoard2 = file.read();

        assertNotEquals(sudokuBoard, sudokuBoard2);
    }

}
