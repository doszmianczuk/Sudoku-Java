package sudokuPackage;

import org.junit.jupiter.api.*;
import sudokuPackage.exception.DaoException;
import sudokuPackage.exception.DatebaseException;

import static org.junit.jupiter.api.Assertions.*;

public class JdbcSudokuBoardDaoTest {

    @Test
    public void databaseUpdateTest() throws DatebaseException {
        SudokuBoard sudokuBoard1 = new SudokuBoard(new BacktrackingSudokuSolver());
        sudokuBoard1.set(0, 0, 1);

        try (Dao<SudokuBoard> jdbcSudokuBoardDao = SudokuBoardDaoFactory.getDatabaseDao("testSudokuBoard")) {
            jdbcSudokuBoardDao.write(sudokuBoard1);
            SudokuBoard sudokuBoard2 = jdbcSudokuBoardDao.read();
            assertEquals(sudokuBoard1, sudokuBoard2);
            sudokuBoard2.set(0,0, 0);
            assertNotEquals(sudokuBoard1, sudokuBoard2);
        } catch (Exception exception) {
            exception.printStackTrace();
            fail();
        }

        assertThrows(DaoException.class, () -> {
            try (Dao<SudokuBoard> jdbcSudokuBoardDao = SudokuBoardDaoFactory.getDatabaseDao("does_not_exist")) {
                jdbcSudokuBoardDao.read();
            } catch (Exception exception) {
                throw new DaoException(exception);
            }
        });
    }
}