package sudokuPackage;

import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

class SudokuBoardTest {

    SudokuSolver backTrackingSolver = new BacktrackingSudokuSolver();
    SudokuBoard testBoard1 = new SudokuBoard(backTrackingSolver);
    SudokuBoard testBoard2 = new SudokuBoard(backTrackingSolver);

    @Test
    void constructorNegative() {
        assertDoesNotThrow(() -> new SudokuBoard(null));
    }

    @Test
    void fillSudoku() {
        testBoard1.solveGame();
        testBoard2.solveGame();
        assertFalse(Arrays.deepEquals(testBoard1.getBoard(), testBoard2.getBoard()));
    }

    @Test
    void checkSudokuRulesZeroNegative() {
        testBoard1.set(0, 0, 1);
        testBoard1.set(0, 1, 1);
        assertFalse(testBoard1.checkBoard());
        assertEquals(testBoard1.checkBoard(), validationFun(testBoard1));
    }

    @Test
    void checkSudokuRulesRowNegative() {
        int[][] sudokuBoardTest = {
                {5, 3, 4, 6, 7, 8, 9, 1, 2},
                {6, 7, 2, 1, 9, 5, 3, 4, 8},
                {1, 9, 8, 3, 4, 2, 5, 6, 7},
                {8, 5, 9, 7, 6, 1, 4, 2, 3},
                {4, 2, 6, 8, 5, 3, 7, 9, 1},
                {7, 1, 3, 9, 2, 4, 8, 5, 6},
                {3, 4, 5, 2, 8, 6, 1, 7, 9},
                {2, 8, 7, 4, 1, 9, 6, 3, 5},
                {2, 6, 1, 5, 3, 7, 8, 8, 4}
        };
        for (int i = 0; i <= 8; i++) {
            for (int j = 0; j <= 8; j++) {
                testBoard1.set(i, j, sudokuBoardTest[i][j]);
            }
        }

        assertFalse(testBoard1.checkBoard());
    }

    @Test
    void checkSudokuRulesColNegative() {
        int[][] sudokuBoardTest = {
                {5, 3, 4, 6, 7, 8, 9, 1, 2},
                {6, 7, 2, 1, 9, 5, 3, 4, 8},
                {1, 9, 8, 3, 4, 2, 5, 6, 7},
                {8, 5, 9, 7, 6, 1, 4, 2, 3},
                {4, 2, 6, 8, 5, 3, 7, 9, 1},
                {7, 1, 3, 9, 2, 4, 8, 5, 6},
                {3, 4, 5, 2, 8, 6, 1, 7, 9},
                {2, 8, 7, 4, 1, 9, 6, 3, 5},
                {2, 6, 1, 5, 3, 7, 8, 8, 4}
        };
        for (int i = 0; i <= 8; i++) {
            for (int j = 0; j <= 8; j++) {
                testBoard1.set(i, j, sudokuBoardTest[i][j]);
            }
        }
        assertFalse(testBoard1.checkBoard());
        assertEquals(testBoard1.checkBoard(), validationFun(testBoard1));
    }

    @Test
    void checkSudokuRulesPositive() {
        testBoard1.solveGame();
        assertEquals(testBoard1.checkBoard(), validationFun(testBoard1));
    }


    @Test
    void isValid() {
        testBoard1.solveGame();
        int[] realNumbers = new int[9];
        int[] expectedNumbers = {1, 2, 3, 4, 5, 6, 7, 8, 9};
        for (int row = 0; row <= 8; row++) {
            for (int col = 0; col <= 8; col++) {
                realNumbers[col] = testBoard1.get(row, col);
            }
            Arrays.sort(realNumbers);
            assertArrayEquals(expectedNumbers, realNumbers);
        }

        for (int col = 0; col <= 8; col++) {
            for (int row = 0; row <= 8; row++) {
                realNumbers[row] = testBoard1.get(row, col);
            }
            Arrays.sort(realNumbers);
            assertArrayEquals(expectedNumbers, realNumbers);
        }

        int rowBlockNumber = 0;
        int columnBlockNumber = 0;
        int cell = 0;
        for (int k = 0; k <= 8; k++) {
            for (int i = rowBlockNumber; i < rowBlockNumber + 3; i++) {
                for (int j = columnBlockNumber; j < columnBlockNumber + 3; j++) {
                    realNumbers[cell] = testBoard1.get(i, j);
                    cell++;
                }
            }
            Arrays.sort(realNumbers);
            assertArrayEquals(expectedNumbers, realNumbers);
            cell = 0;
        }
    }

    @Test
    void getter() {
        assertEquals(0, testBoard1.get(0, 0));
        assertEquals(0, testBoard1.get(6, 3));
        assertEquals(0, testBoard1.get(2, 8));
    }

    @Test
    void setter() {
        testBoard1.set(0, 0, 7);
        assertEquals(7, testBoard1.get(0, 0));
    }


    @Test
    void getRowTest() {
        testBoard1.set(3, 3, 8);
        SudokuRow testRow = testBoard1.getRow(3);
        int[] expectedNumbers = {0, 0, 0, 8, 0, 0, 0, 0, 0};
        for (int i = 0; i < 9; i++) {
            assertEquals(expectedNumbers[i], testRow.getFields().get(i).getFieldValue());
        }
    }

    @Test
    void getColumnTest() {
        testBoard1.set(3, 2, 8);
        SudokuColumn testColumn = testBoard1.getColumn(2);
        int[] expectedNumbers = {0, 0, 0, 8, 0, 0, 0, 0, 0};
        for (int i = 0; i < 9; i++) {
            assertEquals(expectedNumbers[i], testColumn.getFields().get(i).getFieldValue());
        }
    }

    @Test
    void getBoxTest() {
        testBoard1.set(3, 3, 8);
        SudokuBox testBox = testBoard1.getBox(3, 3);
        int[] expectedNumbers = {8, 0, 0, 0, 0, 0, 0, 0, 0};
        for (int i = 0; i < 9; i++) {
            assertEquals(expectedNumbers[i], testBox.getFields().get(i).getFieldValue());
        }
        testBoard1.set(8, 8, 9);
        SudokuBox testBox2 = testBoard1.getBox(8, 8);
        int[] expectedNumbers2 = {0, 0, 0, 0, 0, 0, 0, 0, 9};
        for (int i = 0; i < 9; i++) {
            assertEquals(expectedNumbers2[i], testBox2.getFields().get(i).getFieldValue());
        }
        testBoard1.getBox(10, 10);
        SudokuBox testBox3 = testBoard1.getBox(0, 0);
        int[] expectedNumbers3 = {0, 0, 0, 0, 0, 0, 0, 0, 0};
        for (int i = 0; i < 9; i++) {
            assertEquals(expectedNumbers3[i], testBox3.getFields().get(i).getFieldValue());
        }
    }


    @Test
    void hashCodeToEqualsNotEquals() {
        testBoard1.solveGame();
        testBoard2.solveGame();
        assertNotEquals(testBoard1.hashCode(), testBoard2.hashCode());
        assertFalse(testBoard1.equals(testBoard2));
    }

    @Test
    void hashCodeToEqualsDifferentBoardsSameValuesSameOrderSameSolver() {
        assertEquals(testBoard1.hashCode(), testBoard2.hashCode());
        assertTrue(testBoard1.equals(testBoard2));
    }

    @Test
    void hashCodeToEqualsEqualsTest() {
        testBoard1.solveGame();
        assertEquals(testBoard1.hashCode(), testBoard1.hashCode());
        assertTrue(testBoard1.equals(testBoard1));
    }

    @Test
    void notEqualsToNull() {
        assertFalse(testBoard1.equals(null));
    }

    @Test
    void equalsToItself() {
        assertTrue(testBoard1.equals(testBoard1));
    }

    @Test
    void notEqualsToOtherClass() {
        assertFalse(testBoard1.equals(1));
    }

    @Test
    void toStringPositive() {
        assertEquals("{{0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0}," +
                "{0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0}}" +
                ",BacktrackingSudokuSolver", testBoard1.toString());
    }

    boolean validationFun(SudokuBoard board) {
        int[] realNumbers = new int[9];
        int[] expectedNumbers = {1, 2, 3, 4, 5, 6, 7, 8, 9};
        boolean validation = true;
        for (int row = 0; row <= 8; row++) {
            for (int col = 0; col <= 8; col++) {
                realNumbers[col] = board.get(row, col);
            }
            Arrays.sort(realNumbers);
            validation = Arrays.equals(expectedNumbers, realNumbers);
            if (!validation) {
                return validation;
            }
        }

        for (int col = 0; col <= 8; col++) {
            for (int row = 0; row <= 8; row++) {
                realNumbers[row] = board.get(row, col);
            }
            Arrays.sort(realNumbers);
            validation = Arrays.equals(expectedNumbers, realNumbers);
            if (!validation) {
                return validation;
            }
        }

        int rowBlockNumber = 0;
        int columnBlockNumber = 0;
        int cell = 0;
        for (int k = 0; k <= 8; k++) {
            for (int i = rowBlockNumber; i < rowBlockNumber + 3; i++) {
                for (int j = columnBlockNumber; j < columnBlockNumber + 3; j++) {
                    realNumbers[cell] = board.get(i, j);
                    cell++;
                }
            }
            Arrays.sort(realNumbers);
            validation = Arrays.equals(expectedNumbers, realNumbers);
            cell = 0;
            if (!validation) {
                return validation;
            }
        }
        return validation;
    }

}
