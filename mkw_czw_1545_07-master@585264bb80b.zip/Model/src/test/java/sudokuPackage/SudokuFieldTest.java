package sudokuPackage;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

public class SudokuFieldTest {
    private SudokuField sudokuField;

    @Before
    public void setUp() {
        sudokuField = new SudokuField();
    }


    @Test
    public void getFieldValueTest() {
        assertEquals(sudokuField.getFieldValue(), 0);
    }

    @Test
    public void setFieldValueTest() {
        sudokuField.setFieldValue(5);
        assertEquals(sudokuField.getFieldValue(), 5);
    }

    @Test
    public void sudokuFieldTest() {
        sudokuField = new SudokuField(5);

        assertEquals(sudokuField.getFieldValue(), 5);
    }

    @Test
    public void toStringTest() {
        SudokuField sudokuField = new SudokuField();
        assertNotNull(sudokuField.toString());
    }

    @Test
    public void equalsTest() {
        SudokuField sudokuField = new SudokuField();
        SudokuField sudokuField1 = new SudokuField();
        assertTrue(sudokuField.equals(sudokuField1) && sudokuField1.equals(sudokuField));
    }

    @Test
    public void notequalsTest() {
        SudokuField sudokuField = new SudokuField();
        SudokuField sudokuField1 = new SudokuField();
        sudokuField.setFieldValue(5);
        assertFalse(sudokuField.equals(sudokuField1) && sudokuField1.equals(sudokuField));
    }

    @Test
    public void inCorrectObjectToEqualsTest() {
        SudokuField sudokuField = new SudokuField();
        SudokuSolver backtrackingSolver = new BacktrackingSudokuSolver();
        SudokuBoard sudokuboard  = new SudokuBoard(backtrackingSolver);
        assertTrue(sudokuField.equals(sudokuField));
        assertFalse(sudokuField.equals(null));
        assertFalse(sudokuField.equals(sudokuboard));
    }

    @Test
    public void hashCodeTest() {
        SudokuField sudokuField = new SudokuField();
        SudokuField sudokuField1 = new SudokuField();
        Assertions.assertEquals(sudokuField.hashCode(), sudokuField1.hashCode());
    }

    @Test
    public void differentHashCodeTest() {
        SudokuField sudokuField = new SudokuField();
        SudokuField sudokuField1 = new SudokuField();
        sudokuField.setFieldValue(5);
        assertNotEquals(sudokuField.hashCode(), sudokuField1.hashCode());
    }

    SudokuField testField = new SudokuField();

    @Test
    public void getter() {
        Assertions.assertEquals(0, testField.getFieldValue());
    }

    @Test
    public void intParameterConstructorPositive() {
        SudokuField testField2 = new SudokuField(5);
        Assertions.assertEquals(5, testField2.getFieldValue());
    }

    @Test
    public void objectParameterConstructorPositive() {
        SudokuField testField2 = new SudokuField(5);
        SudokuField testField3 = new SudokuField(testField2);
        Assertions.assertEquals(5, testField3.getFieldValue());
    }

    @Test
    public void objectParameterConstructorNegative() {
        SudokuField testField3 = new SudokuField(null);
        Assertions.assertEquals(0, testField3.getFieldValue());
    }

    @Test
    public void setterPositive() {
        testField.setFieldValue(2);
        Assertions.assertEquals(2, testField.getFieldValue());
    }

    @Test
    public void setterOverBoundNegative() {
        testField.setFieldValue(10);
        Assertions.assertEquals(0, testField.getFieldValue());
    }

    @Test
    public void setterUnderBoundNegative() {
        testField.setFieldValue(-1);
        Assertions.assertEquals(0, testField.getFieldValue());
    }

    @Test
    public void hashCodeToEqualsNotEquals() {
        SudokuField testField1 = new SudokuField(1);
        SudokuField testField2 = new SudokuField(2);
        assertNotEquals(testField1.hashCode(), testField2.hashCode());
        assertFalse(testField1.equals(testField2));
    }

    @Test
    public void hashCodeToEqualsEqualsTest() {
        SudokuField testField1 = new SudokuField(1);
        SudokuField testField2 = new SudokuField(1);
        Assertions.assertEquals(testField1.hashCode(), testField2.hashCode());
        assertTrue(testField1.equals(testField2));
    }

    @Test
    public void notEqualsToNull() {
        assertFalse(testField.equals(null));
    }

    @Test
    public void equalsToItself() {
        assertTrue(testField.equals(testField));
    }

    @Test
    public void notEqualsToOtherClass() {
        assertFalse(testField.equals(1));
    }

    @Test
    public void toStringPositive() {
        SudokuField testField1 = new SudokuField(1);
        Assertions.assertEquals(testField1.toString(), "1");
    }

    @Test
    public void copyFieldTest() {
        SudokuField originalField = new SudokuField(5);
        SudokuField copiedField = new SudokuField(originalField);

        assertNotSame(originalField, copiedField); // Rozłączność obiektów

        assertEquals(originalField.getFieldValue(), copiedField.getFieldValue()); // Równość wartości
    }

    @Test
    public void compareToWithNullTest() {
        SudokuField field = new SudokuField(3);

        assertThrows(NullPointerException.class, () -> {
            field.compareTo(null);
        });
    }

    @Test
    public void cloneTest() {
        SudokuField originalField = new SudokuField(3);

        try {
            SudokuField clonedField = (SudokuField) originalField.clone();

            assertNotSame(originalField, clonedField); // Rozłączność obiektów

            assertEquals(originalField.getFieldValue(), clonedField.getFieldValue()); // Równość wartości
        } catch (CloneNotSupportedException e) {
            fail("Wrong " + e.getMessage());
        }
    }

    @Test
    public void compareToTest() {
        SudokuField field1 = new SudokuField(2);
        SudokuField field2 = new SudokuField(5);
        SudokuField field3 = new SudokuField(2);

        assertTrue(field1.compareTo(field2) < 0);
        assertTrue(field2.compareTo(field1) > 0);
        assertTrue(field1.compareTo(field3) == 0);
    }


}