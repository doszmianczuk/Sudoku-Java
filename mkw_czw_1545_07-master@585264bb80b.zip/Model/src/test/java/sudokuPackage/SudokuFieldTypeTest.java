package sudokuPackage;

import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

public class SudokuFieldTypeTest {

    @Test
    public void verifyCorrect() {
        List<SudokuField> elements = Arrays.asList(new SudokuField[9]);
        for (int i = 0; i < 9; i++) {
            elements.set(i, new SudokuField());
            elements.get(i).setFieldValue(i+1);
        }
        SudokuRow sudoku = new SudokuRow(elements);
        assertTrue(sudoku.verify());
    }
    @Test
    public void verifyValidTest() {
        SudokuRow sudokuRow = new SudokuRow(Arrays.asList(
                new SudokuField(1),
                new SudokuField(2),
                new SudokuField(3),
                new SudokuField(4),
                new SudokuField(5),
                new SudokuField(6),
                new SudokuField(7),
                new SudokuField(8),
                new SudokuField(9)));
        assertTrue(sudokuRow.verify());
    }

    @Test
    public void verifyValidColTest() {
        SudokuColumn sudokuColumn = new SudokuColumn(Arrays.asList(
                new SudokuField(1),
                new SudokuField(2),
                new SudokuField(3),
                new SudokuField(4),
                new SudokuField(5),
                new SudokuField(6),
                new SudokuField(7),
                new SudokuField(8),
                new SudokuField(9)));
        assertTrue(sudokuColumn.verify());
    }

    @Test
    public void verifyValidBoxTest() {
        SudokuBox sudokuBox = new SudokuBox(Arrays.asList(
                new SudokuField(1),
                new SudokuField(2),
                new SudokuField(3),
                new SudokuField(4),
                new SudokuField(5),
                new SudokuField(6),
                new SudokuField(7),
                new SudokuField(8),
                new SudokuField(9)));
        assertTrue(sudokuBox.verify());
    }
    @Test
    public void verifyInvalidTest() {
        SudokuRow sudokuRow = new SudokuRow(Arrays.asList(
                new SudokuField(2),
                new SudokuField(2),
                new SudokuField(3),
                new SudokuField(4),
                new SudokuField(5),
                new SudokuField(6),
                new SudokuField(7),
                new SudokuField(8),
                new SudokuField(9)));
        assertFalse(sudokuRow.verify());
    }

    @Test
    public void toStringTest() {
        List<SudokuField> elements = Arrays.asList(new SudokuField[9]);
        for (int i = 0; i < 9; i++) {
            elements.set(i, new SudokuField());
        }
        SudokuRow sudoku = new SudokuRow(elements);
        assertNotNull(sudoku.toString());
    }


    @Test
    public void notequalsTest() {
        List<SudokuField> elements = Arrays.asList(new SudokuField[9]);
        for (int i = 0; i < 9; i++) {
            elements.set(i, new SudokuField());
        }
        SudokuRow sudoku = new SudokuRow(elements);

        List<SudokuField> elements1 = Arrays.asList(new SudokuField[9]);
        for (int i = 0; i < 9; i++) {
            elements1.set(i, new SudokuField());
            elements.get(i).setFieldValue(i+1);
        }
        SudokuRow sudoku1 = new SudokuRow(elements1);

        assertFalse(sudoku.equals(sudoku1) && sudoku1.equals(sudoku));
    }

    @Test
    public void inCorrectObjectToEqualsTest() {
        List<SudokuField> elements = Arrays.asList(new SudokuField[9]);
        for (int i = 0; i < 9; i++) {
            elements.set(i, new SudokuField());
        }
        SudokuRow sudoku = new SudokuRow(elements);

        SudokuField field = new SudokuField();
        assertTrue(sudoku.equals(sudoku));
        assertFalse(sudoku.equals(null));
        assertFalse(sudoku.equals(field));
    }

    @Test
    public void hashCodeTest() {
        List<SudokuField> elements = Arrays.asList(new SudokuField[9]);
        for (int i = 0; i < 9; i++) {
            elements.set(i, new SudokuField());
        }
        SudokuRow sudoku = new SudokuRow(elements);

        List<SudokuField> elements1 = Arrays.asList(new SudokuField[9]);
        for (int i = 0; i < 9; i++) {
            elements1.set(i, new SudokuField());
        }
        SudokuRow sudoku1 = new SudokuRow(elements1);
        assertEquals(sudoku.hashCode(), sudoku1.hashCode());
    }

    @Test
    public void differentHashCodeTest() {
        List<SudokuField> elements = Arrays.asList(new SudokuField[9]);
        for (int i = 0; i < 9; i++) {
            elements.set(i, new SudokuField());
        }
        SudokuRow sudoku = new SudokuRow(elements);

        List<SudokuField> elements1 = Arrays.asList(new SudokuField[9]);
        for (int i = 0; i < 9; i++) {
            elements1.set(i, new SudokuField());
            elements.get(i).setFieldValue(i+1);
        }
        SudokuRow sudoku1 = new SudokuRow(elements1);
        assertNotEquals(sudoku.hashCode(), sudoku1.hashCode());
    }

    @Test
    public void constructorTest() {
        SudokuFieldType testRow = new SudokuRow();
        for (SudokuField field : testRow.getFields()) {
            assertEquals(0, field.getFieldValue());
        }
    }

    @Test
    public void parameterConstructorList() {
        List<SudokuField> testList = Arrays.asList(new SudokuField[9]);
        for (int i = 0; i < 9; i++) {
            testList.set(i, new SudokuField(i));
        }
        SudokuRow testRow = new SudokuRow(testList);
        for (int i = 0; i < 9; i++) {
            assertEquals(testList.get(i).getFieldValue(), testRow.getFields().get(i).getFieldValue());
        }
    }



    @Test
    public void setterFieldsPositive() {
        SudokuFieldType testRow = new SudokuRow();
        int[] expectedNumbers = {1, 2, 3, 4, 5, 6, 7, 8, 9};
        testRow.setFields(expectedNumbers);
        for (int i = 0; i < 9; i++) {
            assertEquals(expectedNumbers[i], testRow.getFields().get(i).getFieldValue());
        }
    }

    @Test
    public void setterFieldsNullNegative() {
        SudokuFieldType testRow = new SudokuRow();
        int[] expectedNumbers = null;
        testRow.setFields(expectedNumbers);
        for (int i = 0; i < 9; i++) {
            assertEquals(0, testRow.getFields().get(i).getFieldValue());
        }
    }

    @Test
    public void setterFieldsSizeNegative() {
        SudokuFieldType testRow = new SudokuRow();
        int[] expectedNumbers = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12};
        testRow.setFields(expectedNumbers);
        for (int i = 0; i < 9; i++) {
            assertEquals(0, testRow.getFields().get(i).getFieldValue());
        }
    }


    @Test
    public void testVerifySortedPositive() { //posortowane liczby
        SudokuFieldType testRow = new SudokuRow();
        int[] numbers = {1, 2, 3, 4, 5, 6, 7, 8, 9};
        testRow.setFields(numbers);
        assertTrue(testRow.verify());
    }

    @Test
    public void testVerifyUnsortedPositive() { //nieposortowane liczby
        SudokuFieldType testRow = new SudokuRow();
        int[] numbers = {3, 2, 1, 4, 5, 9, 8, 6, 7};
        testRow.setFields(numbers);
        assertTrue(testRow.verify());
    }

    @Test
    public void testVerifyDoubleNegative() { //powtorzenie liczby
        SudokuFieldType testRow = new SudokuRow();
        int[] numbers = {3, 2, 1, 4, 2, 9, 8, 6, 7};
        testRow.setFields(numbers);
        assertFalse(testRow.verify());
    }

    @Test
    public void testVerifyEmptyNegative() { //brak liczby
        SudokuFieldType testRow = new SudokuRow();
        int[] numbers = {3, 2, 1, 4, 0, 9, 8, 6, 7};
        testRow.setFields(numbers);
        assertFalse(testRow.verify());
    }

    @Test
    public void testVerifyIncorrectNumberNegative() { //bledna liczba
        SudokuFieldType testRow = new SudokuRow();
        int[] numbers = {3, 2, 1, 4, 11, 9, 8, 6, 7};
        testRow.setFields(numbers);
        assertFalse(testRow.verify());
    }
    @Test
    public void cloneRowTest() {
        List<SudokuField> originalFields = new ArrayList<>();
        originalFields.add(new SudokuField(1));
        originalFields.add(new SudokuField(2));
        originalFields.add(new SudokuField(3));
        originalFields.add(new SudokuField(4));
        originalFields.add(new SudokuField(5));
        originalFields.add(new SudokuField(6));
        originalFields.add(new SudokuField(7));
        originalFields.add(new SudokuField(8));
        originalFields.add(new SudokuField(9));

        SudokuRow originalRow = new SudokuRow(originalFields);

        try {
            SudokuRow clonedRow = (SudokuRow) originalRow.clone();
            List<SudokuField> clonedFields = clonedRow.getSudokuFieldList();
            assertEquals(originalFields.size(), clonedFields.size());

            for (int i = 0; i < originalFields.size(); i++) {
                assertEquals(originalFields.get(i).getFieldValue(), clonedFields.get(i).getFieldValue());
            }
            assertNotSame(originalFields, clonedFields);
            assertNotSame(originalRow, clonedRow);

        } catch (CloneNotSupportedException e) {
            fail("Can not clone: " + e.getMessage());
        }
    }

    @Test
    public void cloneColumnTest() {
        List<SudokuField> originalFields = new ArrayList<>();
        originalFields.add(new SudokuField(1));
        originalFields.add(new SudokuField(2));
        originalFields.add(new SudokuField(3));
        originalFields.add(new SudokuField(4));
        originalFields.add(new SudokuField(5));
        originalFields.add(new SudokuField(6));
        originalFields.add(new SudokuField(7));
        originalFields.add(new SudokuField(8));
        originalFields.add(new SudokuField(9));

        SudokuColumn originalColumn = new SudokuColumn(originalFields);

        try {
            SudokuColumn clonedColumn = (SudokuColumn) originalColumn.clone();
            List<SudokuField> clonedFields = clonedColumn.getSudokuFieldList();
            assertEquals(originalFields.size(), clonedFields.size());

            for (int i = 0; i < originalFields.size(); i++) {
                assertEquals(originalFields.get(i).getFieldValue(), clonedFields.get(i).getFieldValue());
            }
            assertNotSame(originalFields, clonedFields);
            assertNotSame(originalColumn, clonedColumn);

        } catch (CloneNotSupportedException e) {
            fail("Can not clone: " + e.getMessage());
        }
    }

    @Test
    public void cloneBoxTest() {
        List<SudokuField> originalFields = new ArrayList<>();
        originalFields.add(new SudokuField(1));
        originalFields.add(new SudokuField(2));
        originalFields.add(new SudokuField(3));
        originalFields.add(new SudokuField(4));
        originalFields.add(new SudokuField(5));
        originalFields.add(new SudokuField(6));
        originalFields.add(new SudokuField(7));
        originalFields.add(new SudokuField(8));
        originalFields.add(new SudokuField(9));

        SudokuBox originalBox = new SudokuBox(originalFields);

        try {
            SudokuBox clonedBox = (SudokuBox) originalBox.clone();

            List<SudokuField> clonedFields = clonedBox.getSudokuFieldList();
            assertEquals(originalFields.size(), clonedFields.size());

            for (int i = 0; i < originalFields.size(); i++) {
                assertEquals(originalFields.get(i).getFieldValue(), clonedFields.get(i).getFieldValue());
            }

            assertNotSame(originalFields, clonedFields);
            assertNotSame(originalBox, clonedBox);

        } catch (CloneNotSupportedException e) {
            fail("Can not clone: " + e.getMessage());
        }
    }
}
