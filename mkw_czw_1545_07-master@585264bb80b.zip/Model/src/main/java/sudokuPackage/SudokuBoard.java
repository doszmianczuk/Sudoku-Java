package sudokuPackage;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;
import java.util.*;

import static org.apache.commons.lang3.builder.ToStringStyle.SIMPLE_STYLE;

public class SudokuBoard implements Serializable, Cloneable {
    private final int size = 9;
    public Object clone;
    private SudokuSolver sudokuSolver;
    private final SudokuField[][] board = new SudokuField[size][size];
    private Random random = new Random();
    public SudokuBoard(SudokuSolver sudSol) {
        if (Objects.isNull(sudSol)) {
            sudokuSolver = new BacktrackingSudokuSolver();
        } else {
            sudokuSolver = sudSol;
        }
        for (int i = 0; i <= 8; i++) {
            for (int j = 0; j <= 8; j++) {
                board[i][j] = new SudokuField();
            }
        }
    }

    public int get(int x, int y) {
        return board[x][y].getFieldValue();
    }

    public void set(int x, int y, int value) {
        board[x][y].setFieldValue(value);
    }

    public void removeRandomCell(int setEmptyFields) {
        int row = random.nextInt(9);
        int col = random.nextInt(9);
        int i = 0;
        while (i < setEmptyFields) {
            row = random.nextInt(9);
            col = random.nextInt(9);
            if (this.get(row, col) != 0) {
                this.set(row, col, 0);
                i++;
            }
        }
    }
    public SudokuField[][] getBoard() {
        SudokuField[][] copiedBoard = new SudokuField[size][size];
        for (int i = 0; i < board.length; i++) {
            System.arraycopy(board[i], 0, copiedBoard[i], 0, board[i].length);
        }
        return copiedBoard;
    }

    public SudokuRow getRow(int x) {
        int[] values = new int[9];
        SudokuRow selectedRow = new SudokuRow();

        for (int i = 0; i <= 8; i++) {
            values[i] = this.get(x, i);
        }

        selectedRow.setFields(values);
        return selectedRow;
    }

    public SudokuColumn getColumn(int y) {
        int[] values = new int[9];
        SudokuColumn selectedCol = new SudokuColumn();

        for (int i = 0; i <= 8; i++) {
            values[i] = this.get(i, y);
        }

        selectedCol.setFields(values);
        return selectedCol;
    }

    public SudokuBox getBox(int x, int y) {
        int[] values = new int[9];
        int counter = 0;
        int colBlockNum = 0;
        int rowBlockNum = 0;

        if (x > 2 && x < 6) {
            colBlockNum = 3;
        } else if (x > 5 && x < 9) {
            colBlockNum = 6;
        }

        if (y > 2 && y < 6) {
            rowBlockNum = 3;
        } else if (y > 5 && y < 9) {
            rowBlockNum = 6;
        }

        for (int i = colBlockNum; i < colBlockNum + 3; i++) {
            for (int j = rowBlockNum; j < rowBlockNum + 3; j++) {
                values[counter] = this.get(i, j);
                counter++;
            }
        }
        SudokuBox selectedBox = new SudokuBox();
        selectedBox.setFields(values);
        return selectedBox;
    }

    public SudokuField getFieldXY(int x, int y) {
        return board[x][y];
    }

    public void solveGame() {
        sudokuSolver.solve(this);
    }

    public boolean checkBoard() {
        boolean validation = true;

        for (int row = 0; row <= 8; row++) {
            for (int col = 0; col <= 8; col++) {
                if (this.get(row, col) == 0) {
                    return false;
                }
            }
        }

        for (int row = 0; row <= 8; row++) {
            SudokuRow selectedRow = this.getRow(row);
            validation = selectedRow.verify();
        }

        for (int col = 0; col <= 8; col++) {
            SudokuColumn selectedCol = this.getColumn(col);
            if (!(!validation && selectedCol.verify())) {

                validation = selectedCol.verify();
            }
        }

        for (int x = 0; x <= 8; x++) {
            for (int y = 0; y <= 8; y++) {
                SudokuBox selectedBox = this.getBox(x, y);
                if (!(!validation && selectedBox.verify())) {
                    validation = selectedBox.verify();
                }
            }
        }

        return validation;
    }

    public SudokuField[][] getGameBoard() {
        SudokuField[][] copiedBoard = new SudokuField[size][size];
        for (int i = 0; i < board.length; i++) {
            System.arraycopy(board[i], 0, copiedBoard[i], 0, board[i].length);
        }
        return copiedBoard;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, SIMPLE_STYLE)
                .append(board)
                .append(sudokuSolver.getClass().getSimpleName())
                .toString();
    }

    @Override
    public boolean equals(final Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        if (obj.getClass() != getClass()) {
            return false;
        }
        EqualsBuilder boardEqualsBuilder = new EqualsBuilder();
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                boardEqualsBuilder.append(get(i, j), ((SudokuBoard) obj).get(i, j));
            }
        }
        SudokuBoard comparedBoard = (SudokuBoard) obj;

        return boardEqualsBuilder.append(sudokuSolver, comparedBoard.sudokuSolver).isEquals();
    }

    @Override
    public int hashCode() {
        HashCodeBuilder boardHashBuilder = new HashCodeBuilder(17, 37);
        return boardHashBuilder.append(board).append(sudokuSolver).toHashCode();
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        SudokuSolver solver = new BacktrackingSudokuSolver();
        SudokuBoard sudokuBoard = new SudokuBoard(solver);
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                sudokuBoard.set(i, j, get(i, j));
            }
        }

        return sudokuBoard;
    }
}