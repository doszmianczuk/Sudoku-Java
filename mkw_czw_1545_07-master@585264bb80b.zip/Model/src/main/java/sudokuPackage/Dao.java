package sudokuPackage;

import sudokuPackage.exception.DaoException;
import sudokuPackage.exception.DatebaseException;

public interface Dao<T> extends AutoCloseable {

    T read() throws DaoException, DatebaseException;

    void write(T obj) throws DaoException, DatebaseException;
}
