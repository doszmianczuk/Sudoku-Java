package sudokuPackage;

import java.util.ArrayList;
import java.util.List;

public class SudokuColumn extends SudokuFieldType {
    public SudokuColumn(final List<SudokuField> values) {
        super(values);
    }

    public SudokuColumn() {

    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        List<SudokuField> fields = new ArrayList<>(getSudokuFieldList());
        return new SudokuColumn(fields);
    }
}
