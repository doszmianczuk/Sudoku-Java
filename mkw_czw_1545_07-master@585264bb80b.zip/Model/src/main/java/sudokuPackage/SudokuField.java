package sudokuPackage;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import sudokuPackage.exception.BadFieldValueException;

import java.io.Serializable;
import java.util.Objects;
import java.util.ResourceBundle;

import static org.apache.commons.lang3.builder.ToStringStyle.SIMPLE_STYLE;

public class SudokuField implements Serializable, Cloneable, Comparable<SudokuField> {
    private int value;
   // private ResourceBundle bundle = ResourceBundle.getBundle("Language");

    public SudokuField() {
    }

    public SudokuField(int value) {
        this.setFieldValue(value);
    }

    public SudokuField(SudokuField oldField) {
        if (Objects.isNull(oldField)) {
            this.setFieldValue(0);
        } else {
            this.setFieldValue(oldField.getFieldValue());
        }
    }

    public int getFieldValue() {
        return value;
    }

    public void setFieldValue(int value) {
        if (value < 0 || value > 9) {
            throw new BadFieldValueException("wrong value of field");
        }
        this.value = value;
    }
    @Override
    public String toString() {
        return new ToStringBuilder(this, SIMPLE_STYLE)
                .append(value)
                .toString();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        if (obj.getClass() != getClass()) {
            return false;
        }
        SudokuField comparedField = (SudokuField) obj;

        return new EqualsBuilder()
                .append(value, comparedField.value)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(value)
                .toHashCode();
    }

    @Override
    public int compareTo(SudokuField o) {
        if (o == null) {
            throw new NullPointerException();
        }
        return Integer.compare(this.value, o.value);
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
