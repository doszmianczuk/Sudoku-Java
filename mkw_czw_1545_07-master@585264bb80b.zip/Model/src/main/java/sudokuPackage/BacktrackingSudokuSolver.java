package sudokuPackage;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class BacktrackingSudokuSolver implements SudokuSolver {
    @Override
    public void solve(SudokuBoard board) {
        List<Integer> numbers = new ArrayList<>();

        for (int i = 1; i <= 9; i++) {
            numbers.add(i);
        }
        Collections.shuffle(numbers);

        for (int row = 0; row <= 8; row++) {
            for (int col = 0; col <= 8; col++) {
                if (board.get(row, col) == 0) {
                    for (int number : numbers) {
                        if (this.isValid(number, row, col, board)) {
                            board.set(row, col, number);
                            solve(board);
                            if (board.get(8, 8) != 0) {
                                return;
                            } else {
                                board.set(row, col, 0);
                            }
                        }
                    }
                    return;
                }
            }
        }
    }

    private boolean isValid(int checkedNumber, int row, int col, SudokuBoard board) {

        //Sprawdzenie wiersza
        for (int i = 0; i < 9; i++) {
            if (checkedNumber == board.get(row, i)) {
                return false;
            }
        }
        //Sprawdzenie kolumny
        for (int i = 0; i < 9; i++) {
            if (checkedNumber == board.get(i, col)) {
                return false;
            }
        }
        //Sprawdzenie bloku 3x3
        int rowBlockNumber = (row / 3) * 3;
        int columnBlockNumber = (col / 3) * 3;
        for (int i = rowBlockNumber; i < rowBlockNumber + 3; i++) {
            for (int j = columnBlockNumber; j < columnBlockNumber + 3; j++) {
                if (checkedNumber == board.get(i, j)) {
                    return false;
                }
            }
        }
        return true;
    }
}
