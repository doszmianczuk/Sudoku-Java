package sudokuPackage;

import sudokuPackage.exception.DaoException;
import sudokuPackage.exception.DatebaseException;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class JdbcSudokuBoardDao implements Dao<SudokuBoard>{

    private static final String DBName = "jdbc:derby:" + System.getenv("APPDATA") + "/SudokuGame/Database/sudokuDb2;create=true";
    private String boardName;

    public JdbcSudokuBoardDao(String boardName) throws DatebaseException {
        this.boardName = boardName;
        createTables();
    }


    private static void createTables() throws DatebaseException {
        try (Connection connection = DriverManager.getConnection(DBName);
             Statement statement = connection.createStatement()) {
            connection.setAutoCommit(false);

            try {
                statement.executeUpdate("CREATE TABLE sudoku_boards (board_name VARCHAR(255), board_id VARCHAR(36))");
            } catch (SQLException exception) {
                if (!exception.getSQLState().equals("X0Y32")) {
                    throw exception;
                }
            }

            try {
                statement.executeUpdate("CREATE TABLE board_fields (board_id VARCHAR(36), cellX INT, cellY INT, value INT)");
            } catch (SQLException exception) {
                if (!exception.getSQLState().equals("X0Y32")) {
                    throw exception;
                }
            }

            connection.commit();
        } catch (SQLException exception) {
            throw new DatebaseException(exception);
        }
    }

    public static List<String> getBoardNames() throws DatebaseException {
        createTables();
        try (Connection connection = DriverManager.getConnection(DBName);
             Statement statement = connection.createStatement();
             ResultSet boards = statement.executeQuery("SELECT board_name FROM sudoku_boards")) {
            List<String> boardNames = new ArrayList<>();
            while (boards.next()) {
                boardNames.add(boards.getString("board_name"));
            }
            return boardNames;
        } catch (SQLException exception) {
            throw new DatebaseException(exception);
        }
    }

    @Override
    public SudokuBoard read() throws DatebaseException {
        SudokuBoard board;
        try (Connection connection = DriverManager.getConnection(DBName);
             PreparedStatement ps = connection.prepareStatement(
                     "SELECT * FROM board_fields"
                             + " JOIN sudoku_boards ON sudoku_boards.board_id = board_fields.board_id"
                             + " WHERE board_name = ?")) {
            ps.setString(1, boardName);
            try (ResultSet fields = ps.executeQuery()) {
                board = new SudokuBoard(new BacktrackingSudokuSolver());
                if (!fields.next()) {
                    throw new DatebaseException();
                }
                do {
                    int cellX = fields.getInt("cellX");
                    int cellY = fields.getInt("cellY");
                    int value = fields.getInt("value");
                    board.set(cellX, cellY, value);
                } while (fields.next());
            }
        } catch (Exception exception) {
            throw new DatebaseException(exception);
        }
        return board;
    }

    @Override
    public void write(SudokuBoard sudokuBoard) throws DaoException {
        String boardID = UUID.randomUUID().toString();
        try (Connection connection = DriverManager.getConnection(DBName)) {
            connection.setAutoCommit(false);
            try (PreparedStatement ps = connection.prepareStatement(
                    "DELETE FROM sudoku_boards WHERE board_name = ?")) {
                ps.setString(1, boardName);
                ps.executeUpdate();
            }
            try (PreparedStatement ps = connection.prepareStatement(
                    "INSERT INTO sudoku_boards (board_name, board_id) VALUES (?, ?)")) {
                ps.setString(1, boardName);
                ps.setString(2, boardID);
                ps.executeUpdate();
            }
            connection.commit();
        } catch (SQLException exception) {
            throw new DaoException(exception);
        }

        try (Connection connection = DriverManager.getConnection(DBName)) {
            connection.setAutoCommit(false);
            try (PreparedStatement ps = connection.prepareStatement(
                    "DELETE FROM board_fields WHERE board_id = ?")) {
                ps.setString(1, boardID);
                ps.executeUpdate();
            }

            try (PreparedStatement ps = connection.prepareStatement(
                    "INSERT INTO board_fields (board_id, cellX, cellY, value) VALUES (?, ?, ?, ?)")) {
                for (int x = 0; x < 9; x++) {
                    for (int y = 0; y < 9; y++) {
                        int value = sudokuBoard.getFieldXY(x, y).getFieldValue();
                        ps.setString(1, boardID);
                        ps.setInt(2, x);
                        ps.setInt(3, y);
                        ps.setInt(4, value);
                        ps.executeUpdate();
                    }
                }
            }

            connection.commit();
        } catch (SQLException exception) {
            throw new DaoException(exception);
        }
    }

    @Override
    public void close() {
    }
}
