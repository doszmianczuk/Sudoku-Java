package sudokuPackage;

import java.util.ArrayList;
import java.util.List;

public class SudokuRow extends SudokuFieldType {
    public SudokuRow(final List<SudokuField> values) {
        super(values);
    }

    public SudokuRow() {
        super();
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        List<SudokuField> fields = new ArrayList<>(getSudokuFieldList());
        return new SudokuRow(fields);
    }
}
