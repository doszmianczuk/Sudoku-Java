package sudokuPackage.exception;

public class FileErrorException extends DaoException {
    public FileErrorException(Throwable cause) {
        super(cause);
    }
}
