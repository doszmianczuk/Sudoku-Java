package sudokuPackage.exception;

import java.sql.SQLException;

public class DatebaseException extends SQLException {
    public DatebaseException(Throwable cause) {
        super(cause);
    }

    public DatebaseException() {

    }
}
