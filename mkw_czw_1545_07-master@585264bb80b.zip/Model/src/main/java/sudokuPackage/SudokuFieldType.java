package sudokuPackage;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;
import java.util.*;

import static org.apache.commons.lang3.builder.ToStringStyle.SIMPLE_STYLE;

public abstract class SudokuFieldType implements Cloneable, Serializable {
    private List<SudokuField> fields = Arrays.asList(new SudokuField[9]);


    public SudokuFieldType(int[] values) {
        if (Objects.isNull(values) || values.length != 9) {
            for (int i = 0; i <= 8; i++) {
                fields.set(i, new SudokuField());
            }
        } else {
            for (int i = 0; i <= 8; i++) {
                fields.set(i, new SudokuField(values[i]));
            }
        }
    }

    public SudokuFieldType(List<SudokuField> values) {
        if (Objects.isNull(values) || values.size() != 9) {
            for (int i = 0; i <= 8; i++) {
                fields.set(i, new SudokuField());
            }
        } else {
            fields = values;
        }
    }


    public SudokuFieldType() {
        for (int i = 0; i <= 8; i++) {
            fields.set(i, new SudokuField());
        }
    }

    public List<SudokuField> getFields() {
        return Collections.unmodifiableList(fields);
    }

    public void setFields(int[] copiedFields) {
        if (Objects.isNull(copiedFields) == false && copiedFields.length == 9) {
            for (int i = 0; i <= 8; i++) {
                fields.get(i).setFieldValue(copiedFields[i]);
            }
        }
    }

    public List<SudokuField> getSudokuFieldList() {
        return Collections.unmodifiableList(fields);
    }

    public boolean verify() {
        List<Integer> testList = Arrays.asList(new Integer[9]);
        List<Integer> originalList = Arrays.asList(new Integer[9]);

        for (int i = 0; i < 9; i++) {
            originalList.set(i, fields.get(i).getFieldValue());
        }
        int counter = 1;
        for (int i = 0; i < 9; i++) {
            testList.set(i, counter);
            counter++;
        }
        return new HashSet<>(originalList).containsAll(testList);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, SIMPLE_STYLE)
                .append(fields)
                .toString();
    }

    @Override
    public boolean equals(final Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        if (obj.getClass() != getClass()) {
            return false;
        }

        SudokuFieldType comparedPiece = (SudokuFieldType) obj;
        EqualsBuilder pieceEqualsBuilder = new EqualsBuilder();

        for (SudokuField field : fields) {
            for (SudokuField field1 : comparedPiece.fields) {
                pieceEqualsBuilder.append(field.getFieldValue(), field1.getFieldValue());
            }

        }
        return pieceEqualsBuilder.appendSuper(super.equals(obj)).isEquals();
    }

    @Override
    public int hashCode() {
        HashCodeBuilder pieceHashCodeBuilder = new HashCodeBuilder(17, 37);
        for (SudokuField field : fields) {
            pieceHashCodeBuilder.append(field.getFieldValue());
        }
        return pieceHashCodeBuilder.toHashCode();
    }


}
