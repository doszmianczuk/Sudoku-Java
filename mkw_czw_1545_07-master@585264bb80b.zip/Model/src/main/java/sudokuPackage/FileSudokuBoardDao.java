package sudokuPackage;

import sudokuPackage.exception.FileErrorException;

import java.io.*;

public class FileSudokuBoardDao implements Dao<SudokuBoard> {
    private final String fileName;

    public FileSudokuBoardDao(String filename) {
        this.fileName = filename;
    }

    @Override
    public SudokuBoard read() throws FileErrorException {
        try (FileInputStream fileIn = new FileInputStream(fileName)) {
            ObjectInputStream objectIn = new ObjectInputStream(fileIn);
            return (SudokuBoard) objectIn.readObject();
        } catch (IOException | ClassNotFoundException e) {
            throw new FileErrorException(e);
        }
    }

    @Override
    public void write(SudokuBoard obj) throws FileErrorException {
        try (FileOutputStream fOS = new FileOutputStream(fileName);
             ObjectOutputStream objectOutputStream = new ObjectOutputStream(fOS)) {
            objectOutputStream.writeObject(obj);
        } catch (IOException e) {
            throw new FileErrorException(e);
        }
    }

    @Override
    public void close(){

    }
}
