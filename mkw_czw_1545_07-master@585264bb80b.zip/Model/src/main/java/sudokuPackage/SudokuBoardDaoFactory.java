package sudokuPackage;

import sudokuPackage.exception.DatebaseException;

public class SudokuBoardDaoFactory {
    public Dao<SudokuBoard> getFileDao(String fileName) {
        return new FileSudokuBoardDao(fileName);
    }

    public static Dao<SudokuBoard> getDatabaseDao(String filename) throws DatebaseException {
        return new JdbcSudokuBoardDao(filename);
    }
}
