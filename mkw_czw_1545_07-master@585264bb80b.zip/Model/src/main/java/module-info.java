module ModelProject {
    requires org.apache.commons.lang3;
    requires java.sql;

    exports sudokuPackage;
    exports sudokuPackage.exception;
}
