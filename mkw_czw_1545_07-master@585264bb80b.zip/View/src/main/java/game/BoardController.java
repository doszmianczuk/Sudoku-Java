package game;

import javafx.animation.PauseTransition;
import javafx.beans.binding.Bindings;
import javafx.beans.property.IntegerProperty;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.adapter.JavaBeanIntegerProperty;
import javafx.beans.property.adapter.JavaBeanIntegerPropertyBuilder;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.util.converter.IntegerStringConverter;
import sudokuPackage.BacktrackingSudokuSolver;
import sudokuPackage.JdbcSudokuBoardDao;
import sudokuPackage.*;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.ResourceBundle;
import java.util.logging.Logger;


public class BoardController extends IntegerStringConverter {

    private ResourceBundle bundle = ResourceBundle.getBundle("Language");
    static Logger logger = Logger.getLogger(BoardController.class.getName());

    @FXML
    private ResourceBundle resources;

    @FXML
    private GridPane sudokuBoardGrid;

    @FXML
    BorderPane borderPane;

    @FXML
    private Parent root;
    SudokuBoard sudokuBoard;
    @FXML
    private Label chceckInfo;
    private SudokuBoard board = new SudokuBoard(new BacktrackingSudokuSolver());
    private final List<TextField> textFields = new ArrayList<>();
    JavaBeanIntegerProperty[] cellProperty = new JavaBeanIntegerProperty[81];
    TextField[] textFieldsBD = new TextField[81];

    @FXML
    private void initialize() {
        for (Node node : borderPane.getChildren()) {
            if (node instanceof GridPane) {
                for (int i = 0; i < 9; i++) {
                    for (int j = 0; j < 9; j++) {
                        TextField ss = new TextField();
                        textFields.add(ss);
                        ss.setAlignment(Pos.CENTER);
                        ((GridPane) node).add(ss, i, j);
                    }
                }
            }
        }
        logger.info(bundle.getString("readyGame"));
    }

    @FXML
    public void checkSudoku(MouseEvent event) throws IOException {
        this.chceckInfo.setStyle("-fx-font-size: 50px");
        if (board.checkBoard()) {
            this.chceckInfo.setText(bundle.getString("wonLabel"));
            this.chceckInfo.setStyle("-fx-text-fill: green");

        } else {
            this.chceckInfo.setText(bundle.getString("lostLabel"));
            this.chceckInfo.setStyle("-fx-text-fill: red");
        }

        PauseTransition pause = new PauseTransition(Duration.seconds(5));
        pause.setOnFinished(e -> chceckInfo.setText(""));
        pause.play();
    }



    public void setTextFields() {
        for (int i = 0; i < textFields.size(); i++) {
            int row = i / 9;
            int col = i % 9;

            IntegerProperty tt = new SimpleIntegerProperty(board.getFieldXY(row, col).getFieldValue());
            TextFormatter testFormatter = new TextFormatter(new Converter(), 0, new IntegerRegex());
            Bindings.bindBidirectional(testFormatter.valueProperty(), tt);
            textFields.get(i).setTextFormatter(testFormatter);
        }
        for (int i = 0; i < textFields.size(); i++) {
            TextField textField = textFields.get(i);
            int finalI = i;
            textField.textProperty().addListener((observable, oldValue, newValue) -> {
                int row = finalI / 9;
                int col = finalI % 9;
                board.set(row, col, Integer.parseInt(newValue));
            });
        }
    }


    @FXML
    void loadDatabase(ActionEvent event) throws IOException {
        String boardNameDatabase;
        try {
            List<String> boardNames = JdbcSudokuBoardDao.getBoardNames();

            ChoiceDialog<String> dialog = new ChoiceDialog<>();
            for (String boardName : boardNames) {
                dialog.getItems().add(boardName);
            }
            dialog.showAndWait();

            if (dialog.getResult() == null) {
                return;
            }
            boardNameDatabase = dialog.getResult();
            try (Dao<SudokuBoard> dao = SudokuBoardDaoFactory.getDatabaseDao(boardNameDatabase)) {
                setLoadedBoard(dao.read());
            } catch (Exception exception) {
                throw new RuntimeException(exception);
            }
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }
    }

    @FXML
    void loadFile(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle(bundle.getString("loadButton"));
        File selectedFile = fileChooser.showOpenDialog(new Stage());

        if (selectedFile != null) {
            try {
                SudokuBoardDaoFactory daoFactory = new SudokuBoardDaoFactory();
                Dao<SudokuBoard> fileDao = daoFactory.getFileDao(selectedFile.getAbsolutePath());

                SudokuBoard loadedBoard = fileDao.read();
                fileDao.close();

                logger.info(bundle.getString("loadedFile"));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    @FXML
    void saveFile(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle(bundle.getString("saveButon"));
        File selectedFile = fileChooser.showSaveDialog(new Stage());

        if (selectedFile != null) {
            try {
                SudokuBoardDaoFactory daoFactory = new SudokuBoardDaoFactory();
                Dao<SudokuBoard> fileDao = daoFactory.getFileDao(selectedFile.getAbsolutePath());
                SudokuBoard copyBoard = new SudokuBoard(new BacktrackingSudokuSolver());
                fileDao.write(copyBoard);
                fileDao.close();
                logger.info(bundle.getString("savedFile"));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @FXML
    void saveToDatabase(ActionEvent event) throws IOException {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setGraphic(null);
        dialog.showAndWait();
        if (dialog.getResult() == null) {
            return;
        }

        String boardNameDatabase = dialog.getResult();
        try (Dao<SudokuBoard> dao = SudokuBoardDaoFactory.getDatabaseDao(boardNameDatabase)) {
            dao.write(board);
        } catch (Exception exception) {
            throw new RuntimeException(exception);
        }

    }

    public void setBoard(SudokuBoard board) {
        this.board = board;
    }

    public void setLoadedBoard(SudokuBoard board) throws NoSuchMethodException {
        this.board = board;
        for (Node node : borderPane.getChildren()) {
            if (node instanceof GridPane) {
                for (int i = 0; i < 9; i++) {
                    for (int j = 0; j < 9; j++) {
                        TextField field = new TextField();
                        field.setAlignment(Pos.CENTER);
                        textFieldsBD[i * 9 + j] = field;
                        ((GridPane) node).add(field, i, j);
                    }
                }
            }
        }

        JavaBeanIntegerPropertyBuilder builder = JavaBeanIntegerPropertyBuilder.create();
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                if (cellProperty[i] != null) {
                    textFieldsBD[i].textProperty().unbindBidirectional(cellProperty[i]);
                    cellProperty[i].dispose();
                }
                cellProperty[i] = builder.bean(board.getFieldXY(i,j))
                        .name("FieldValue")
                        .build();

                textFieldsBD[i].textProperty().bindBidirectional(cellProperty[i], new Converter());

            }
        }
    }


    @Override
    public Integer fromString(String s) {
        if (s.matches("[1-9]?")) {
            return super.fromString(s);
        }
        if (s.matches("")){
            return 0;
        }
        return null;
    }

    @Override
    public String toString(Integer integer) {
        if(Objects.isNull(integer)){
            return "";
        }
        if (integer >= 1 && integer <= 9) {
            return super.toString(integer);
        }
        else {
            return "";
        }
    }
}

