package game;

import sudokuPackage.SudokuBoard;

public class SudokuDifficulty {
    public enum DifficultyLevel {
        EASY,
        MEDIUM,
        HARD;

        private DifficultyLevel() {
        }
    }

    public static void setSudokuDifficulty(SudokuBoard givenSudokuBoard, DifficultyLevel difficulty) {
        try {
            switch (difficulty) {
                case EASY:
                    givenSudokuBoard.removeRandomCell(1);
                    break;
                case MEDIUM:
                    givenSudokuBoard.removeRandomCell(20);
                    break;
                case HARD:
                    givenSudokuBoard.removeRandomCell(30);
                    break;
                    default:
                        givenSudokuBoard.removeRandomCell(1);
                        break;
            }
        } catch (NullPointerException | IllegalArgumentException e) {
            throw e;
        }
    }
}
