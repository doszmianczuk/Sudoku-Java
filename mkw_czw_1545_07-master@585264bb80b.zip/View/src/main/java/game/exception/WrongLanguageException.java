package game.exception;

public class WrongLanguageException extends myRuntimeEx{
    public WrongLanguageException() {
    }
}
