package game.exception;

public class myRuntimeEx extends RuntimeException{
    public myRuntimeEx() {
    }
}
