package game.exception;

public class WrongLevelException extends myRuntimeEx{
    public WrongLevelException() {
    }
}
