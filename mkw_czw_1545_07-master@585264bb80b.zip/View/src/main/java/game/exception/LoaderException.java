package game.exception;

import java.io.IOException;

public class LoaderException extends RuntimeException{
    public LoaderException(IOException e) {
    }
}
