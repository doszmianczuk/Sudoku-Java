package game.exception;

public class WrongFileException extends EmptyBoardException {
    public WrongFileException(String message) {
        super(message);
    }
}
