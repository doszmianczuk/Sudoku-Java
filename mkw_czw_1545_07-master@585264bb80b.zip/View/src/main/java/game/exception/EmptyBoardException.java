package game.exception;

public class EmptyBoardException extends Exception{
    public EmptyBoardException(String message) {
        super(message);
    }
}
