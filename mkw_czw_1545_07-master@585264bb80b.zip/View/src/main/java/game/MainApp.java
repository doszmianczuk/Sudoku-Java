package game;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.util.Locale;
import java.util.ResourceBundle;
import java.util.logging.LogManager;
import java.io.IOException;
import java.io.InputStream;

public class MainApp extends Application {

    @Override
    public void start(Stage primaryStage) throws IOException {
        ResourceBundle bundle = ResourceBundle.getBundle("Language");
        Parent root = FXMLLoader.load(getClass().getResource("/game/choiceWindow.fxml"), bundle);
        primaryStage.setTitle("Sudoku");
        primaryStage.resizableProperty().setValue(false);
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }

    static {
        try (InputStream configFile = MainApp.class.getClassLoader().getResourceAsStream("logging.properties")) {
            LogManager.getLogManager().readConfiguration(configFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}