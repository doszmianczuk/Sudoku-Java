package game;

import game.exception.LoaderException;
import game.exception.WrongLanguageException;
import game.exception.WrongLevelException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import sudokuPackage.*;

import java.io.IOException;
import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.logging.Logger;

public class ChoiceController implements Initializable {
    ResourceBundle bundle = ResourceBundle.getBundle("Language");
    static Logger logger = Logger.getLogger(BoardController.class.getName());

    @FXML
    private ToggleButton easyButton;
    @FXML
    private ToggleButton mediumButton;
    @FXML
    private ToggleButton hardButton;

    @FXML
    private ComboBox languageChoose;

    private static String difficulty = "VERY_EASY";

    private String language;

    @FXML
    private ResourceBundle resources;

    @FXML
    private Parent root;

    @FXML
    private Stage stage;
    private static SudokuBoard sudokuBoardFromSource;
    public static SudokuBoard getSudokuBoardFromSource() {
        return sudokuBoardFromSource;
    }
    private Dao<SudokuBoard> jdbcSudokuBoardDao;

    @FXML
    void authorInfo(MouseEvent event) {
        ResourceBundle listBundle = ResourceBundle.getBundle("game.Authors");
        logger.info(bundle.getString("authorsButton") + listBundle.getObject("1) ") + "\n" + listBundle.getObject("2) "));
    }

    public void getDifficulty() throws WrongLevelException{
        try {
            if (easyButton.isSelected()) {
                difficulty = "EASY";
            } else if (mediumButton.isSelected()) {
                difficulty = "MEDIUM";
            } else if (hardButton.isSelected()) {
                difficulty = "HARD";
            }
            logger.info(bundle.getString("choiceInfo"));
        } catch (WrongLevelException e) {
            logger.warning(bundle.getString("wrongLvlEx"));
        }
    }


    @FXML
    void confirmLanguage(MouseEvent event) throws WrongLanguageException {
        try {
            this.language = languageChoose.getSelectionModel().getSelectedItem().toString();

            if (language.equals(bundle.getString("langEn"))) {
                Locale.setDefault(new Locale("en"));
                FXMLLoader loader = new FXMLLoader(getClass().getResource("ChoiceWindow.fxml"));
                loader.setResources(ResourceBundle.getBundle("Language"));
                root = loader.load();
                stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                stage.setScene(new Scene(root));
                stage.show();

            } else if (language.equals(bundle.getString("langPl"))) {
                Locale.setDefault(new Locale("pl"));
                FXMLLoader loader = new FXMLLoader(getClass().getResource("ChoiceWindow.fxml"));
                loader.setResources(ResourceBundle.getBundle("Language"));
                root = loader.load();
                stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                stage.setScene(new Scene(root));
                stage.show();
            }


            logger.info("Confirm language setttings");
        } catch (WrongLanguageException e) {
            logger.warning(bundle.getString("wrongLangEx"));
        } catch (IOException e) {
            throw new LoaderException(e);
        }
    }

    public SudokuBoard getBoard() {
        SudokuBoard board = new SudokuBoard(null);
        board.solveGame();
        switch (this.difficulty) {
            case "EASY":{
                SudokuDifficulty.setSudokuDifficulty(board, SudokuDifficulty.DifficultyLevel.EASY);
                break;
            }
            case "MEDIUM":{
                SudokuDifficulty.setSudokuDifficulty(board, SudokuDifficulty.DifficultyLevel.MEDIUM);
                break;
            }
            case "HARD":{
                SudokuDifficulty.setSudokuDifficulty(board, SudokuDifficulty.DifficultyLevel.HARD);
                break;
            }
        }
        return board;
    }

    @FXML
    void startSudoku(MouseEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("boardWindow.fxml"), bundle);
        root = loader.load();
        BoardController boardController = loader.getController();
        boardController.setBoard(this.getBoard());
        boardController.setTextFields();
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setTitle("Sudoku Game");
        stage.setScene(new Scene(root));
        stage.show();
    }



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        languageChoose.getItems().addAll(
                bundle.getString("langEn"),
                bundle.getString("langPl")
        );
    }
}
