package game;

import java.util.ListResourceBundle;

public class Authors_en extends ListResourceBundle {

    @Override
    protected Object[][] getContents() {
        return new Object[][]{
                {"1) ", "Zuzana Lewandowska ",},
                {"2) ", "Dawid Oszmiańczuk "}
        };
    }
}
