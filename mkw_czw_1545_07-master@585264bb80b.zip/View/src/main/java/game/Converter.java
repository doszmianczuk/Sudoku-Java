package game;

import javafx.util.converter.NumberStringConverter;

public class Converter extends NumberStringConverter {

    @Override
    public String toString(Number number) {
        return number != null && number.intValue() != 0 ? super.toString(number) : "";
    }

    @Override
    public Number fromString(String s) {
        return s != null && !s.isEmpty() ? super.fromString(s) : 0;
    }
}
