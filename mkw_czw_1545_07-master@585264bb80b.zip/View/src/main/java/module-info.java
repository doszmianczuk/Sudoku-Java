module ViewModel {
    requires javafx.graphics;
    requires javafx.fxml;
    requires javafx.controls;
    requires ModelProject;
    requires java.logging;

    opens game to javafx.fxml;
    exports game;
}
